/* COP 3502C Assignment 4 
This program is written by: Kyle Anthony Franklin */ 
#include <stdio.h>
#include <stdlib.h>
#include "leak_detector_c.h"

static FILE* inFile;
static FILE* outFile;
#define Threshold 25

void merge(long long arr[], int l, int m, int r);
void mergeSort(long long arr[], int l, int r);
long long  output(long long arr[], long long maxPages,long long Size);
//void insertionSort(int arr[], long long l, long long r);

int main(){
  atexit(report_mem_leak);

  inFile = fopen("test_in1.txt", "r");
  outFile = fopen("test_out1.txt", "w");

  int numTestCases,numBooks;
  long long maxPages;
  int inOrder =0;
  fscanf(inFile, "%d", &numTestCases);
  for(int i =0; i< numTestCases;i++){
    fscanf(inFile, "%d %lld", &numBooks, &maxPages);
    long long *booksToRead = (long long*) malloc(numBooks*sizeof(long long));
    for(int j = 0; j< numBooks;j++){
      fscanf(inFile, "%lld", &booksToRead[j]);
    }
    for(int j = 0; j< numBooks-1;j++){
      if(booksToRead[j]>booksToRead[j+1]){
        inOrder=-1;
        break;
      }
    }
    if(inOrder==-1){
      mergeSort(booksToRead, 0, numBooks-1);
    }
    printf("%lld\n", output(booksToRead, maxPages,numBooks));
    fprintf(outFile,"%lld\n", output(booksToRead, maxPages, numBooks));
    free(booksToRead);
  }
  x = (-b - sqrt(b * b - 4 * a * c)) / (2 * a);

  return 0;
}

// Merges two subarrays of the given array.
void merge(long long  arr[], int l, int m, int r){
  int leftSize = m - l + 1;
  int rightSize =  r - m;

  //arrays for the left and right
  long long *leftSide = (long long*) malloc(leftSize*sizeof(long long));
  long long *rightSide = (long long*) malloc(rightSize*sizeof(long long));

  //seperates all the data into the left or right array
  for (int i = 0; i < leftSize; i++){
    leftSide[i] = arr[l + i];
  }
  for (int i = 0; i < rightSize; i++){
    rightSide[i] = arr[m + 1+ i];
  }

  int i = 0;
  int j = 0;
  int k = l;

  //merges the left and right array back into the main array
  while (i < leftSize && j < rightSize){
    if (leftSide[i] <= rightSide[j]){
      arr[k] = leftSide[i];
      i++;
      k++;
    }
    else{
      arr[k] = rightSide[j];
      j++;
      k++;
    }
  }

  //copies the remaining elements from the left side
  while (i < leftSize){
    arr[k] = leftSide[i];
    i++;
    k++;
  }
  
  //copies the remaining  elements from the right side
  while (j < rightSize){
    arr[k] = rightSide[j];
    j++;
    k++;
  }
  free(leftSide);
  free(rightSide);
}

//defines the mid and then calls then starts the process for sorting
void mergeSort(long long arr[], int l, int r){
  if (l < r){
    // get the mid point
    int m = (l+r)/2;
      
    // Sort first and second halves
    mergeSort(arr, l, m);
    mergeSort(arr, m+1, r);

    merge(arr, l, m, r);
  }
}

//calculates how many books will be read, returns long long due to unknown amount of books read
long long  output(long long arr[], long long maxPages,long long Size){
    long long count = 0;
    int booksRead=0;
    
    if(count+arr[booksRead+1] >= maxPages){
      booksRead++;
      return booksRead;
    }
    while(count+arr[booksRead] <= maxPages){
      count+=arr[booksRead];
      booksRead++;
      if(booksRead==Size){
        break;
      }
    }
  return booksRead;
}


  // my attempt at adding insertion sort to the code it crashed on larger test cases
/*
void sort(int arr[], long long l, long long r){
  //if (r - l > Threshold) {
    long long m = (l + r) / 2;
    sort(arr, l, r);
    sort(arr, m + 1, r);
    merge(arr, l, m, r);
  //}
  else {
    insertionSort(arr, l, r);
  }
}

// kept on crashing with larger test cases
void insertionSort(int arr[], long long l, long long r){
  for (int i = l; i < r; i++) {
        int tempVal = arr[i + 1];
        int j = i + 1;
        while (j > l && arr[j - 1] > tempVal) {
            arr[j] = arr[j - 1];
            j--;
        }
        arr[j] = tempVal;
    }
}
*/