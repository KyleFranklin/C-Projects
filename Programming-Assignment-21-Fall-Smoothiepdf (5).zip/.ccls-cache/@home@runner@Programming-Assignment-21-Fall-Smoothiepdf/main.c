/* COP 3502C Assignment 1
This program is written by: Kyle Anthony Franklin */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "leak_detector_c.h"

#define MAXLENGTH 21

static FILE* inFile;
static FILE* outFile;

typedef struct item {     
  int itemID;     
  int numParts; 
} item;

typedef struct recipe {     
  int numItems;     
  item* itemList;     
  int totalParts; 
} recipe;

// Pre-condition: reference to a variable to store number of ingredients.
// Post-condition: Reads in numIngredients and that number of strings from
// the inputs, allocates an array of
// strings to store the input, and sizes each
// individual string dynamically to be the
// proper size (string length plus 1), and
// returns a pointer to the array.
char** readIngredients(int *numIngrediants){
  //scanning in the number of ingrediants
  fscanf(inFile,"%d", numIngrediants);
  char** ingrediants=malloc(*numIngrediants *sizeof(ingrediants));
  char temp[MAXLENGTH];
  for(int i = 0; i < *numIngrediants; i++){
    //scanning in the ingrediants name
    fscanf(inFile, "%s", temp);
    //allocating the correct amount of space for the string
    ingrediants[i] = malloc(sizeof(char) * (strlen(temp) + 1));
    //copying the ingrediant name from temp
    strcpy(ingrediants[i], temp);
  }
  return ingrediants;
}

// Pre-condition: does not take any parameter
// Post-condition: Reads in details of a recipe such as numItems,
// Dynamically allocates space for a single
// recipe, dynamically allocates an array of
// item of the proper size, updates the
// numItems field of the struct, fills the
// array of items appropriately based on the
// input and returns a pointer to the struct
// dynamically allocated.
recipe* readRecipe(){
  recipe *recipe;
  // number of ingredieants in each recipe
  int required;
  //temperary variable for the total parts in each recipe
  int count=0;
  //takes in the te total amount of ingrediants
  fscanf(inFile,"%d", &required);
  //make one recipe
  recipe=malloc(sizeof(recipe));

  recipe->numItems = required;
  //allocating the memory for the items themselves
  recipe->itemList = (item*) malloc(required* sizeof(item));

  for(int i =0;i< required;i++){
    //scanning in the item ids per recipe
    fscanf(inFile,"%d", &(recipe->itemList[i].itemID));
    //scanning in the lbs per each recipe
    fscanf(inFile,"%d", &(recipe->itemList[i].numParts));
    //adding up the total parts of each recipe
    count+=recipe->itemList[i].numParts;
  }
  //setting total parts to the correct value
  recipe->totalParts = count;
  return recipe;
}

// Pre-condition: reference to a variable to store number of recipes.
// Post-condition: Read number of recipes. Dynamically allocates an array of
//pointers to recipes of size numRecipes, reads numRecipes
// number of recipes from standard input, creates
// structs to store each recipe and has the 
// pointers point to each struct, in the order
// the information was read in. (Should call
// readRecipe in a loop.)
recipe** readAllRecipes(int *numRecipes){
  recipe** menue;
  //total number of recipies
  fscanf(inFile,"%d", numRecipes);// 3
  menue = (recipe**)malloc(*numRecipes * sizeof(recipe*));
  for(int i =0; i<*numRecipes;i++){
    //calling the recipe
    menue[i]=readRecipe();
  }
 
  return menue;
}

// Pre-conditions: ingredientList is an array of char* of size
// numIngredients with each char* dynamically allocated.
// Post-condition: all the memory pointed to by ingredientList is
// freed.
void freeIngredients(char** ingredientList, int numIngredients){
  for(int i = 0; i<numIngredients; i++){
    //freeing each string individualy
    free(ingredientList[i]);
  }
  //freeing the rest of ingrediants
  free(ingredientList);
}

// Pre-conditions: allRecipes is an array of recipe* of size
// numRecipes with each recipe* dynamically allocated
// to point to a single recipe.
// Post-condition: all the memory pointed to by allRecipes is
// freed.
void freeRecipes(recipe** allRecipes, int numRecipes){
  for(int i = 0; i<numRecipes; i++){
    //freeing the items first, then the recipe at that location
    free(allRecipes[i]->itemList);
    free(allRecipes[i]);

  }
  //freeing the whole recipe
  free(allRecipes);
}

// Pre-condition: 0 < numSmoothies <= 100000, recipeList is
// pointing to the list of all smoothie recipes and
// numIngredients equals the number of total ingredients (you have
// alreadyread it in the first line of the input).
// Post-condition: Reads in information from standard input
// about numSmoothies number of smoothie orders and dynamically
// allocates an array of doubles of size numIngredients such
// that index i stores the # of pounds of ingredient i
// needed to fulfill all smoothie orders and returns a pointer
// to the array.
double* calculateOrder(int ingredientCount, int numSmoothies, recipe** recipeList){
  double* amtOfEachItem;
  amtOfEachItem=calloc(ingredientCount, sizeof(double));
  int numOrders;
  //the recipe number the store needs
  int numRecipe;
  //the amount of lbs the store needs
  double lbs;
  //place holder for the calculation
  double calc;
  fscanf(inFile,"%d",&numOrders);// 2
  //going through each order 
  for(int j =0; j < numOrders;j++){
    fscanf(inFile,"%d %lf",&numRecipe, &lbs);// 1 10
    //going through and toatling up each ingrediant
    for(int k =0; k<recipeList[numRecipe]->numItems;k++){
      //calculating each ingrediant
      amtOfEachItem[recipeList[numRecipe]->itemList[k].itemID] += (recipeList[numRecipe]->itemList[k].numParts* lbs)/ recipeList[numRecipe]->totalParts;
    }
  }
  return amtOfEachItem;
}

// Pre-conditions: ingredientNames store the names of each
// ingredient and orderList stores the amount
// to order for each ingredient, and both arrays
// are of size numIngredients.
// Post-condition: Prints out a list, in ingredient order, of each
// ingredient, a space and the amount of that
// ingredient to order rounded to 6 decimal
// places. One ingredient per line.
void printOrder(char** ingredientNames, double* orderList, int numIngredients){
  for(int i = 0; i < numIngredients;i++){
    if(orderList[i]!=0){
      printf("%s %lf\n",ingredientNames[i],orderList[i]);
      fprintf(outFile,"%s %lf\n",ingredientNames[i],orderList[i]);
    }
  }
}

void processOutput(char** ingredientList, int ingredientCount, recipe** allRecipes, int recipeCount){
  double *amtOfEachItem;
  // the number of stores
  int numStores;
  fscanf(inFile,"%d",&numStores);
  for(int i =0; i< numStores;i++){
    printf("\nStore #%d:\n",i+1);
    fprintf(outFile,"Store #%d:\n",i+1);

    //calling calculateOrder and print order
     amtOfEachItem = calculateOrder(ingredientCount, recipeCount, allRecipes);
    
     printOrder(ingredientList, amtOfEachItem, ingredientCount);

    printf("\n");
    fprintf(outFile,"\n");
    //freeing the calculations
    free(amtOfEachItem);
  }
}

int main(void) {
  atexit(report_mem_leak);

  inFile = fopen("in.txt", "r");
  outFile = fopen("out.txt", "w");
  
  recipe** smoothieList;

  int numIngrediants;
  int numRecipies;

  // this is the ingrediant list
  char** ingrediants;
  //filling the ingrediants list
  ingrediants = readIngredients(&numIngrediants);

  //filling the smoothie list
  smoothieList = readAllRecipes(&numRecipies);

  //aputting all the output together
  processOutput(ingrediants, numIngrediants, smoothieList, numRecipies);

  //freeing the recipes
  freeRecipes(smoothieList, numRecipies);
  freeIngredients(ingrediants, numIngrediants);
  
  fclose(inFile);
  fclose(outFile);
  return 0;
}