/* COP 3502C Assignment 3
This program is written by: Kyle Anthony Franklin */

#include<stdio.h>
#include<stdlib.h>
#include"leak_detector_c.h"

#define MAXSIZE 10

static FILE* inFile;
static FILE* outFile;


// linked list
typedef struct monster{
  int data;
  struct monster* next;
}monster;


typedef struct queue{
  struct monster* front;
  struct monster* back;
  int position;
  int size;
  int Kth;
  int threshhold;
}queue;

monster* createMonster(int sequence);
void createReverseCircle(queue *q);
void rearrangeCircle(queue* q);
void displayall(queue q[]);
void display(queue q);
void enqueue(queue *qPtr, int val);
int isEmpty(queue q);
void init(queue* qPtr);
monster * deleteMonster(monster *previous, monster *next);
monster * deleteMonsterBack(monster * previous, monster *temp, queue *q);
void phase1(queue *q);
int deque(queue *q);
int peek(queue qPtr);
void phase2(queue *q);

void freeQueue(queue *q);

int main(void) {
  atexit(report_mem_leak);

  inFile = fopen("in.txt", "r");
  outFile = fopen("out.txt", "w");

  int testing;// first number
  int position; // position to store into the queue
  queue q[MAXSIZE];//creating my queue

  for(int i =0; i< MAXSIZE;i++){
    init(&q[i]);//Initializing every queue
  }

  fscanf(inFile, "%d", &testing);
  printf("Initial nonempty lists status\n");
  fprintf(outFile,"Initial nonempty lists status\n");
  for(int i =0; i< testing; i++){
    //[,1-8,3,]
    fscanf(inFile, "%d", &position);
    q[position-1].position = position;// storing the queue into its correct position
    createReverseCircle(&q[position-1]);//putting all elements into the queue
  }
  displayall(q);

  printf("\nAfter ordering nonempty lists status\n");
  fprintf(outFile,"\nAfter ordering nonempty lists status\n");
  for(int i =0; i < MAXSIZE;i++){
    if(!isEmpty(q[i])){
      rearrangeCircle(&q[i]);//reversing the queue if its not empty
    }
  }
  displayall(q);

  printf("\nPhase1 execution\n\n");
  fprintf(outFile,"\nPhase1 execution\n\n");
  phase1(q);

  printf("Phase2 execution\n");
  fprintf(outFile,"Phase2 execution\n");
  phase2(q);
  
  fclose(inFile);
  fclose(outFile);
  return 0;
}

monster*  createMonster(int i){//creating each node
	monster *temp;
	temp= (monster *) malloc(sizeof(monster));
	temp->data=i;
	temp->next=NULL;
  return temp;
}

void init(queue* qPtr){// Initializing given queue
  qPtr->front=NULL;
  qPtr->back=NULL;
  qPtr->position=0;
  qPtr->size=0;
  qPtr->Kth=0;
  qPtr->threshhold=0;
}

void enqueue(queue *qPtr, int val) {// putting an emlement into the queue
  monster *temp;
  temp = createMonster(val);
  if(qPtr->back){
      qPtr->back->next = temp;
    }
    qPtr->back = temp;
    if(qPtr->front == NULL){
      qPtr->front = temp;
    }
    qPtr->back->next = qPtr->front;
}

void displayall(queue q[]){ // a function to display all
  for(int i =0; i< MAXSIZE;i++){
    if (!isEmpty(q[i])){
      display(q[i]);
      printf("\n");
      fprintf(outFile, "\n");
    }
  }
}
void display(queue q){// a function to display one queue
  struct monster* temp = q.front;
  printf("%d", q.position);
  fprintf(outFile,"%d", q.position);
  for(int i =0; i < q.size;i++){
    printf(" %d",temp->data);
    fprintf(outFile," %d",temp->data);
		temp = temp->next;
  }
}


void rearrangeCircle(queue* q){// reverses the queue
  //traversal node
  monster* main_list = q->front;
  monster* reverse_list = q->back;
  reverse_list->next=q->front;
  // goes through every node in the linked list
  do{
    monster*temp = main_list;
    main_list = main_list->next;
    temp->next = reverse_list;
    reverse_list = temp;
  }while(main_list!=q->front);// reverwses all but the front and the back
  monster*temp2 = q->front;
  q->front = q->back;
  q->back = temp2;// these few lines reverse these front and back;
}


int isEmpty(queue q) {
    return q.front == NULL;// returns 1 if empty, and 0 if not
}

void createReverseCircle(queue *q){// fills in the queue
    fscanf(inFile, "%d", &q->size);
    fscanf(inFile, "%d", &q->Kth);
    fscanf(inFile, "%d", &q->threshhold);
    for(int i=q->size;i>0;i--){
    enqueue(q, i);
    }
}

int deque(queue *q){// deletes the front of the queue
  int deleted;
  monster *temp = q->front; //cereates a temp node which will enable the deletion
  deleted =temp->data;
  printf("%d ",temp->data); // prints the number being deleted
  fprintf(outFile,"%d ",temp->data);
  q->front = temp->next;
  q->back->next= temp->next;
  free(temp);
  q->size--; // lowers the size
  if(q->size==0){// if it becomes empty set it to null
    q->front=NULL;
    q->back=NULL;
  }
  return deleted;// returnsd the deleted value for phase 2
}

monster * deleteMonster(monster *previous, monster *next){//deletes a mopnster from the middle
  monster* temp = next;
  next = temp->next;
  previous->next= next;
  printf("Monster# %d executed", temp->data);// prints the deleted monster
  fprintf(outFile,"Monster# %d executed", temp->data);
	free(temp);
  return next;
}


monster * deleteMonsterBack(monster * previous, monster *next, queue *q){// deletes a monster frmo the back then updates it
  q->back = previous;
  monster* temp = next;
  next = temp->next;
  previous->next= next;
  printf("Monster# %d executed", temp->data);// prints the deleted monster
  fprintf(outFile,"Monster# %d executed", temp->data);
	free(temp);
  return next;
}

void phase1(queue *q){ // phase 1 function
  int deleted;
  for(int i =0; i< MAXSIZE;i++){
    if(!isEmpty(q[i])){// if its not empty search through and delte every kth
      printf("Line# %d\n", i+1);
      fprintf(outFile,"Line# %d\n", i+1);
      monster *temp= q[i].front;
      monster*previous;
      for(int j =q[i].size; j > q[i].threshhold;j--){// delete until; it reaches the threshold
        for(int k =1;k <q[i].Kth;k++){// traverses every kth node
          previous = temp;
          temp=temp->next;
        }
        if(temp == q[i].front){// if its the front delete from the front
          printf("Monster# ");
          fprintf(outFile,"Monster# ");
          deleted = deque(&q[i]);
          printf("executed");
          fprintf(outFile,"executed");
          temp = q[i].front;
          if(q[i].size==1){ //if it becomes the last node update the back
            q[i].front = q[i].back;
          }
        }
        
        else if(temp->next == q[i].front){// if its the back delete from the back
          q[i].size--;
          temp = deleteMonsterBack(previous, temp, &q[i]);
          if(q[i].size==1){//if it becomes the last node update the front
            q[i].back = q[i].front;
          }
        }
        else{//if its the middle delete from the middle
          q[i].size--;
          temp = deleteMonster(previous, temp);
        }
        printf("\n");
        fprintf(outFile,"\n");
      }
      printf("\n");
      fprintf(outFile,"\n");
    }
  }
}

int peek(queue qPtr){// function to look at the front of a given queue
  return qPtr.front->data;
}

int chekingHighest(queue *q){// finds the highest num of all queues
  int highestNum=-1; 
  int highestGround = -1;
  for(int i =0; i< MAXSIZE;i++){
    if(isEmpty(q[i])){// if it empty skip it
      continue;
    }
    if(peek(q[i]) > highestNum){// update the highest if it finds a higher number
      highestNum = q[i].front->data;
      highestGround=i;
    } 
  }
  return highestGround;// return the index
}

void phase2(queue *q){// phase 2 function
  int counter =0;
  int highestGround;
  int deleted;
  int remainder =0;
  for(int i =0; i< MAXSIZE;i++){// find out how many monsters are left after phase 1
    if(!isEmpty(q[i])){
      remainder+=q[i].size;
    }
  }
  while(remainder>1){// delete until you have 1 left
      highestGround = chekingHighest(q); // gets the index of the highest monster
      printf("Executed Monster ");
      fprintf(outFile,"Executed Monster ");
      deleted = deque(&q[highestGround]);// deletes the highest mosnter
      printf("from line %d\n",q[highestGround].position);
      fprintf(outFile,"from line %d\n",q[highestGround].position);
      remainder--;
  }
  printf("\nMonster ");
  fprintf(outFile,"\nMonster ");
  highestGround = chekingHighest(q);
  deleted = deque(&q[highestGround]);
  printf("from line %d will survive",q[highestGround].position);
  fprintf(outFile,"from line %d will survive",q[highestGround].position);
}