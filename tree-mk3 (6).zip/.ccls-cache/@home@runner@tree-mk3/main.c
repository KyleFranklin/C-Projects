/* COP 3502C Assignment 2 This program is written by: Kyle A. Franklin */
#include <stdio.h>
#include<math.h>
#include <time.h>

#define MAXTREES 16
#define MAXBACKYARDS 25


typedef struct coordinates{
  int x;
  int y;
}coordinates;

double perm( int order[], int trees, int k, int used[], struct coordinates positions[]);
double calclateLength(struct coordinates positions[], int n, int order[]);

int main(void) {
  FILE* inFile;
  FILE* outFile;
  inFile = fopen("in.txt", "r");
  outFile = fopen("out.txt", "w");
  
  int backyards;
  //a place holder variable
  double output;
  //a struct array to store my x's and y's
  struct coordinates positions[MAXTREES];
  // helper array to mark if something is used
  int used [MAXBACKYARDS]={0};

  // a clock to see how long my code takes
  //clock_t t;
  //t = clock();

  fscanf(inFile, "%d", &backyards);
  for(int i =0;i< backyards;i++){
    output=0;
    int trees;
    fscanf(inFile, "%d", &trees);
    //a special test case if you have 0 trees (unsure if this is a requierment)
    if(trees == 0 ){
      printf("%.3lf\n", output);
      fprintf(outFile,"%.3lf\n", output);
    }
    else{
      //a for loop to scan all the coordinates
      for(int j=0;j<trees*2;j++){
        fscanf(inFile, "%d %d", &positions[j].x,&positions[j].y);
      }
      // the array to help with permutations
      int order[MAXBACKYARDS];
      //hard code the first position to always be in 0, for optimization
      order[0]=0;
      //perm function startgin at 1 to compensate for hardcoding the first position in the order array to 0
      output = perm(order, trees*2, 1, used, positions);

      fprintf(outFile,"%.3lf\n", output);
      printf("%.3lf\n", output);
    }
    //t = clock() - t;
    //double time_taken = ((double)t)/CLOCKS_PER_SEC;
    //printf("this test case took %f seconds to execute \n", time_taken);
  }
  fclose(inFile);
  fclose(outFile);
  return 0;
}

double perm( int order[], int trees, int k, int used[], struct coordinates positions[]){
  //base case
  if(k == trees){
    return calclateLength(positions, trees, order);
  }
  // place holder for a maximum value
  double res =10000000000000000;
  //optimization looking at only the even spaces in the array
  if(k%2==0){
    for(int i = order[k-2]+1; i < trees;i++){
      //skip if the osition has been used
      if(used[i]){
        continue;
      }
      //add i to the order so it denotes what to look at when doing permutations
      order[k] = i;
      //marked this position as used
      used[i]=1;
      //recursive call
      double thisRes = perm(order, trees, k+1, used, positions);
      //compare for a maller value
      if(thisRes<res){
        res= thisRes;
      }
      //unmaark it as used
      used[i]=0;
    }
  }
  else{
    //for loop looking at the odd positions for optimization
    for(int i = order[k-1]+1; i < trees;i++){
      //skip if the osition has been used
      if(used[i]){
        continue;
      }
      //add i to the order so it denotes what to look at when doing permutations
      order[k] = i;
      //marked this position as used
      used[i]=1;
      //recursive call
      double thisRes = perm(order, trees, k+1, used, positions);
      //compare for a maller value
      if(thisRes<res){
        res= thisRes;
      }
      //unmaark it as used
      used[i]=0;
    }
  }
  return res;
}

double calclateLength(struct coordinates positions[], int n, int order[]){
  double calc =0;
  //calculating th distacne between all the trees
  for(int i =n-1;i>0 ;i-=2){
    calc += sqrt(pow(positions[order[i]].x-positions[order[i-1]].x,2)+pow(positions[order[i]].y-positions[order[i-1]].y,2));
  }
  return calc;
}

/*
4
4 7 3 3
1 10 3 2
7 9 2 4
3 8 2 1

before phase 1
1 10 9 8 7 6 5 4 3 2 1
3 8 7 6 5 4 3 2 1
4 7 6 5 4 3 2 1
7 9 8 7 6 5 4 3 2 1

then becomes
1 1 2 3 4 5 6 7 8 9 10
3 1 2 3 4 5 6 7 8
4 1 2 3 4 5 6 7
7 1 2 3 4 5 6 7 8 9

phase 1.1
1 1 2 4 5 6 7 8 9 10  //3 is taken out
3 1 3 4 5 6 7 8   
4 1 2 4 5 6 7
7 1 3 4 5 6 7 8 9

phase 1.2
1 1 2 4 5 6 7 8 9 10
3 1 2 3 4 5 6 7 8
4 1 2 3 4 5 6 7
7 1 2 3 4 5 6 7 8 9

*/