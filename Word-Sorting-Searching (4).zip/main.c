/* COP 3502C Assignment 1
This program is written by: Kyle Anthony Franklin */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "leak_detector_c.h"

static FILE* inFile;
static FILE* outFile;

#define MAXWORD 21
#define MAXLENGTH 100

typedef struct data{
  char storedWord [MAXWORD];
  int count;
}data;

typedef struct node{
  struct data data;
  struct node *left;
  struct node *right;
}node;

node* insertion(struct node *head, char word[]);
node* create_node(char s[]);
void search(struct node* n, char key[], int depth);
int numNodes(struct node *node);
int load(struct node* node, data amountOfNodes[], int index);
void mergeSort(data arr[], int l, int r);
void merge(data arr[], int l, int m, int r);
void freeNodes(node* tree);
int compareTo(char s1[], char s2[]); 

int main(void) {
  atexit(report_mem_leak);
  inFile = fopen("in.txt", "r");
  outFile = fopen("out.txt", "w");

  int actions, option, count=0, index =0;
  //creates the tree and sets it to NULL
  node *tree;
  tree = NULL;

  //creates the array for the tree Tree node data
  data *amountOfNodes;
  amountOfNodes =(data*)malloc(sizeof(data)*MAXLENGTH);

  fscanf(inFile,"%d",&actions);
  for(int i=0; i< actions; i++){
    fscanf(inFile,"%d",&option);
    char *word =(char*)malloc(sizeof(char)*MAXWORD);
    fscanf(inFile,"%s", word);
    if(option==1){
      //inserts a node into the tree
      tree = insertion(tree, word);
    }
    else{
      //finds a specific node
      search(tree, word, 0);
    }
    free(word);
  }
  //finds how many nodes there are for the array size
  count =numNodes(tree);
  //stores the root at index 0
  amountOfNodes[index] = tree->data;
  //stores the left side of the root into the array
  index =load(tree->left,amountOfNodes, index+1);
  //stores the right side of the root into the aray
  index =load(tree->right,amountOfNodes, index+1);
  //sorts the array
  mergeSort(amountOfNodes, 0, count-1);
  //prints the array
  for(int i =0; i< count;i++){
    printf("%s %d\n", amountOfNodes[i].storedWord,amountOfNodes[i].count);
    fprintf(outFile, "%s %d\n", amountOfNodes[i].storedWord,amountOfNodes[i].count);
  }
  free(amountOfNodes);
  freeNodes(tree);
}

node* insertion(node *node, char word[]){
  int compare;
  //if its null create_node and makes it a node
  if(node==NULL){
    node = create_node(word);
    return node;
  }
  // if the curerent node  is the same as one that is stored increase the frequency
  else if( compareTo(node->data.storedWord,word) == 0){
    node->data.count++;
    return node;
  }
  else{
    //move to the left if its smaller
    if(compareTo(node->data.storedWord,word)>0){
      node->left = insertion(node->left,word);
    }
    //moce  to the right if its bigger
    else{
      node->right= insertion(node->right,word);
    }
  }
  return node;
}

node* create_node(char s[]){
  //creates a temperary node and returns said node
  node* temp;
  temp = (node*)malloc(sizeof(node));
  strcpy(temp->data.storedWord, s);
  temp->data.count=1;
  temp->right = NULL;
  temp->left=NULL;
  return temp;
}

void search(struct node* node, char key[], int depth){
  //if its not found print -1 -1
  if(node ==NULL){
    printf("%d %d\n",-1, -1);
    fprintf(outFile, "%d %d\n",-1, -1);
    return;
  }
  // if it is found print the depth and its frequenxt
  else if(compareTo(node->data.storedWord,key)==0){
    printf("%d %d\n",node->data.count, depth);
    fprintf(outFile, "%d %d\n",node->data.count, depth);
    return;
  }
  else{
    //if its not found and smaller move to the left
    if(compareTo(node->data.storedWord,key)>0){
      search(node->left, key, depth+1);
    }
    //if its not found and bigger move to the right
    else{
      search(node->right, key, depth+1);
    }
  }
}

int numNodes(struct node *node) {
  // if there is no node at the current node return 0
  if(node==NULL){
    return 0;
  }
  //return 1 + however many nodes are to the left, then do the same with the right
  return 1 + numNodes(node->left) + numNodes(node->right);
}

int load(node *node, data amountOfNodes[], int index){
  //if there is no node dont store it and return 0
  if (node == NULL){
    return 0;
  }
  //if there is a node store it at the current index
  amountOfNodes[index] = node->data;
  //then increase the index and move to the left, then repeat with the right, and return the final index
  return 1 + load(node->left, amountOfNodes, index+1) + load(node->right, amountOfNodes, index+2);
}

void merge(data  arr[], int l, int m, int r){
  int leftSize = m - l + 1;
  int rightSize =  r - m;
  //arrays for the left and right
  data *leftSide = (data*) malloc(leftSize*sizeof(data));
  data *rightSide = (data*) malloc(rightSize*sizeof(data));
  //seperates all the data into the left or right array
  for (int i = 0; i < leftSize; i++){
    leftSide[i] = arr[l + i];
  }
  for (int i = 0; i < rightSize; i++){
    rightSide[i] = arr[m + 1+ i];
  }
  int i = 0;
  int j = 0;
  int k = l;
  //merges the left and right array back into the main array
  while (i < leftSize && j < rightSize){
    //if the frequency is greater it moves to the top
    if (leftSide[i].count > rightSide[j].count){
      arr[k] = leftSide[i];
      i++;
      k++;
    }
    //if there equal check the string
    else if(leftSide[i].count == rightSide[j].count){
      //if the string  is smaller move it to the left
      if(compareTo(leftSide[i].storedWord,rightSide[j].storedWord)<0){
        arr[k] = leftSide[i];
        i++;
        k++;
      }
      //otherwise move it to the botom 
      else{
        arr[k] = rightSide[j];
        j++;
        k++;
      }
    }
    //otherwise move it to the bottom
    else{
      arr[k] = rightSide[j];
      j++;
      k++;
    }
  }

  //copies the remaining elements from the left side
  while (i < leftSize){
    arr[k] = leftSide[i];
    i++;
    k++;
  }
  
  //copies the remaining  elements from the right side
  while (j < rightSize){
    arr[k] = rightSide[j];
    j++;
    k++;
  }
  free(leftSide);
  free(rightSide);
}

//defines the mid and then calls then starts the process for sorting
void mergeSort(data arr[], int l, int r){
  if (l < r){
    // get the mid point
    int m = (l+r)/2;
      
    // Sort first and second halves
    mergeSort(arr, l, m);
    mergeSort(arr, m+1, r);
    merge(arr, l, m, r);
  }
}

void freeNodes(node* tree){
  //if there is no node come back
  if (tree == NULL){
    return;
  }
  //similar to post order but with freeing data instead of printing it
  freeNodes(tree->left);
  freeNodes(tree->right);
  free(tree);
}
// a function for calling string compare
int compareTo(char s1[], char s2[]){
  return strcmp(s1, s2);
}